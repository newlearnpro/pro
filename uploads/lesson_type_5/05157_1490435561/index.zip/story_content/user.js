function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5orbKqjaCeu":
        Script1();
        break;
  }
}

function Script1()
{
  parent.document.getElementsByClassName("lesson_selected")[0].parentElement.nextElementSibling.firstElementChild.click();
}

