function ExecuteScript(strId)
{
  switch (strId)
  {
      case "61I6GmlOJXY":
        Script1();
        break;
  }
}

function Script1()
{
  parent.document.getElementsByClassName("lesson_selected")[0].parentElement.nextElementSibling.firstElementChild.click();
}

